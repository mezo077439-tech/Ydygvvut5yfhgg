import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/config/app_config.dart';
import 'package:shared/design/tokens.dart';
import '../auth/providers/auth_provider.dart';
import 'overview_screen.dart';

class DashboardNavigationScreen extends ConsumerStatefulWidget {
  const DashboardNavigationScreen({super.key});
  @override
  ConsumerState<DashboardNavigationScreen> createState() => _DashboardNavigationScreenState();
}

class _DashboardNavigationScreenState extends ConsumerState<DashboardNavigationScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final role = ref.watch(authNotifierProvider).role ?? AppRole.manager;
    final isManager = role == AppRole.manager;

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: [
          const OverviewScreen(),
          const Scaffold(body: Center(child: Text('الشاشة 2'))),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(LucideIcons.layoutDashboard), label: 'نظرة عامة'),
          NavigationDestination(icon: Icon(LucideIcons.users), label: 'العملاء'),
        ],
      ),
    );
  }
}
