import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/design/tokens.dart';
import 'package:shared/utils/extensions.dart';
import '../auth/providers/auth_provider.dart';

class OverviewScreen extends ConsumerWidget {
  const OverviewScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(icon: const Icon(LucideIcons.logOut), onPressed: () => ref.read(authNotifierProvider.notifier).logout())],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          Text('مرحباً بك، مدير النظام', style: context.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: AppSpacing.lg),
          GridView.count(
            crossAxisCount: 2, crossAxisSpacing: AppSpacing.md, mainAxisSpacing: AppSpacing.md, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 1.2,
            children: [
              _buildStatCard(context, title: 'المشتركين', value: '1,248', icon: LucideIcons.users, color: AppColors.accent1),
              _buildStatCard(context, title: 'الإيرادات', value: '\$4,200', icon: LucideIcons.trendingUp, color: AppColors.accent2),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(BuildContext context, {required String title, required String value, required IconData icon, required Color color}) {
    return Container(
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: AppRadii.radiusMd, border: Border.all(color: color.withOpacity(0.3))),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(icon, color: color, size: 28),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24, color: Colors.white)),
            Text(title, style: const TextStyle(color: AppColors.accent5)),
          ]),
        ],
      ),
    );
  }
}
