import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/design/tokens.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(LucideIcons.shieldCheck, size: 72, color: AppColors.accent2),
            const SizedBox(height: AppSpacing.xl),
            const Text('TO Best', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 2)),
            const Text('Management System', style: TextStyle(fontSize: 16, color: AppColors.accent2)),
            const SizedBox(height: AppSpacing.xxl),
            const CircularProgressIndicator(color: AppColors.accent2),
          ],
        ),
      ),
    );
  }
}
