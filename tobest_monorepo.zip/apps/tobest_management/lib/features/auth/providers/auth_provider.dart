import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared/config/app_config.dart';
import '../../../core/providers.dart';
part 'auth_provider.g.dart';

enum AuthStatus { initial, authenticated, unauthenticated, loading, error }

class AuthState {
  final AuthStatus status;
  final String? errorMessage;
  final AppRole? role;
  const AuthState({this.status = AuthStatus.initial, this.errorMessage, this.role});
  AuthState copyWith({AuthStatus? status, String? errorMessage, AppRole? role}) {
    return AuthState(status: status ?? this.status, errorMessage: errorMessage, role: role ?? this.role);
  }
}

@Riverpod(keepAlive: true)
class AuthNotifier extends _$AuthNotifier {
  @override
  AuthState build() => const AuthState();

  Future<void> checkAuthStatus() async {
    state = state.copyWith(status: AuthStatus.loading);
    final token = await ref.read(localStorageProvider).getAuthToken();
    if (token != null) state = state.copyWith(status: AuthStatus.authenticated, role: AppRole.manager);
    else state = state.copyWith(status: AuthStatus.unauthenticated);
  }

  Future<void> login(String identifier, String password) async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final response = await ref.read(gasApiProvider).callFunction('login', {
        'identifier': identifier, 'password': password, 'appContext': AppConfig.managementAppName,
      });

      AppRole role = _parseRole(response['role'] as String);
      if (!AppConfig.isManagementAppRole(role)) throw Exception('غير مصرح لك بالدخول للإدارة.');
      
      await ref.read(localStorageProvider).saveAuthToken(response['token'] as String);
      state = state.copyWith(status: AuthStatus.authenticated, role: role);
    } catch (e) {
      state = state.copyWith(status: AuthStatus.error, errorMessage: e.toString());
    }
  }

  Future<void> logout() async {
    await ref.read(localStorageProvider).clearAuthToken();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  AppRole _parseRole(String role) {
    if (role == 'manager') return AppRole.manager;
    if (role == 'subscriptions') return AppRole.subscriptions;
    if (role == 'support') return AppRole.support;
    return AppRole.user;
  }
}
