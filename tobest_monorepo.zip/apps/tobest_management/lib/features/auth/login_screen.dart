import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/design/tokens.dart';
import 'package:shared/utils/validators.dart';
import 'package:shared/utils/extensions.dart';
import 'providers/auth_provider.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _identifierController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  void _submitLogin() {
    FocusScope.of(context).unfocus();
    if (_formKey.currentState!.validate()) {
      ref.read(authNotifierProvider.notifier).login(_identifierController.text.trim(), _passwordController.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    ref.listen<AuthState>(authNotifierProvider, (previous, next) {
      if (next.status == AuthStatus.error && next.errorMessage != null) {
        context.showSnackBar(next.errorMessage!, isError: true);
      }
    });

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(AppSpacing.lg),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(LucideIcons.building, size: 80, color: AppColors.accent2),
                  const SizedBox(height: AppSpacing.lg),
                  Text('لوحة الإدارة', textAlign: TextAlign.center, style: context.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: Colors.white)),
                  const SizedBox(height: AppSpacing.xl),
                  TextFormField(
                    controller: _identifierController,
                    decoration: const InputDecoration(labelText: 'المعرف الوظيفي', prefixIcon: Icon(LucideIcons.briefcase), border: OutlineInputBorder()),
                    validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null,
                  ),
                  const SizedBox(height: AppSpacing.md),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: _obscurePassword,
                    decoration: InputDecoration(
                      labelText: 'كلمة المرور', prefixIcon: const Icon(LucideIcons.lock), border: const OutlineInputBorder(),
                      suffixIcon: IconButton(icon: Icon(_obscurePassword ? LucideIcons.eye : LucideIcons.eyeOff), onPressed: () => setState(() => _obscurePassword = !_obscurePassword)),
                    ),
                    validator: Validators.validatePassword,
                  ),
                  const SizedBox(height: AppSpacing.xl),
                  SizedBox(
                    height: 56,
                    child: ElevatedButton(
                      onPressed: authState.status == AuthStatus.loading ? null : _submitLogin,
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent2, foregroundColor: Colors.white),
                      child: authState.status == AuthStatus.loading ? const CircularProgressIndicator(color: Colors.white) : const Text('دخول', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
