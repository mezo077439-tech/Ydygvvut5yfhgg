import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared/data/local_storage_service.dart';
import 'package:shared/data/gas_api_client.dart';
part 'providers.g.dart';

@Riverpod(keepAlive: true)
LocalStorageService localStorage(LocalStorageRef ref) {
  throw UnimplementedError('يجب عمل override لهذا المزود في main.dart');
}

@Riverpod(keepAlive: true)
GasApiClient gasApi(GasApiRef ref) {
  return GasApiClient(ref.watch(localStorageProvider));
}
