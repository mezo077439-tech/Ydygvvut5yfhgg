import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared/design/themes.dart';
import 'package:shared/infrastructure/background_service.dart';
import 'package:shared/data/local_storage_service.dart';
import 'core/providers.dart';
import 'features/auth/providers/auth_provider.dart';
import 'features/splash/splash_screen.dart';
import 'features/auth/login_screen.dart';
import 'features/home/main_navigation_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  BackgroundService.initialize();
  BackgroundService.registerPeriodicSync();
  final localStorage = LocalStorageService();
  await localStorage.init();

  runApp(ProviderScope(
    overrides: [localStorageProvider.overrideWithValue(localStorage)],
    child: const ToBestApp(),
  ));
}

class ToBestApp extends ConsumerWidget {
  const ToBestApp({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'TO Best',
      debugShowCheckedModeBanner: false,
      theme: AppThemes.getLightTheme('ar'),
      darkTheme: AppThemes.getDarkTheme('ar'),
      themeMode: ThemeMode.system,
      home: const AuthGuard(),
    );
  }
}

class AuthGuard extends ConsumerStatefulWidget {
  const AuthGuard({super.key});
  @override
  ConsumerState<AuthGuard> createState() => _AuthGuardState();
}

class _AuthGuardState extends ConsumerState<AuthGuard> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(authNotifierProvider.notifier).checkAuthStatus();
    });
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authNotifierProvider);
    switch (authState.status) {
      case AuthStatus.initial:
      case AuthStatus.loading: return const SplashScreen();
      case AuthStatus.unauthenticated:
      case AuthStatus.error: return const LoginScreen();
      case AuthStatus.authenticated: return const MainNavigationScreen();
    }
  }
}
