import 'package:flutter/material.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/design/tokens.dart';
import 'home_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});
  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    const HomeScreen(),
    const Scaffold(body: Center(child: Text('التمارين'))),
    const Scaffold(body: Center(child: Text('التغذية'))),
    const Scaffold(body: Center(child: Text('حسابي'))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (i) => setState(() => _currentIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(LucideIcons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(LucideIcons.dumbbell), label: 'التمارين'),
          NavigationDestination(icon: Icon(LucideIcons.apple), label: 'التغذية'),
          NavigationDestination(icon: Icon(LucideIcons.user), label: 'حسابي'),
        ],
      ),
    );
  }
}
