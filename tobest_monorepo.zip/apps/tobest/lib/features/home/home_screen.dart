import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:shared/design/tokens.dart';
import 'package:shared/utils/extensions.dart';
import '../auth/providers/auth_provider.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نظرة عامة', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(icon: const Icon(LucideIcons.logOut), onPressed: () => ref.read(authNotifierProvider.notifier).logout())],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.md),
        children: [
          Text('مرحباً بك،', style: context.textTheme.titleLarge?.copyWith(color: AppColors.accent5)),
          Text('إليك ملخص اليوم', style: context.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold, color: AppColors.accent1)),
          const SizedBox(height: AppSpacing.lg),
          _buildActionCard(context, title: 'تمرين اليوم', subtitle: 'اليوم الأول: دفع', icon: LucideIcons.dumbbell, color: AppColors.accent1),
          const SizedBox(height: AppSpacing.md),
          _buildActionCard(context, title: 'التغذية والماكروز', subtitle: 'متبقي: 1200 سعرة', icon: LucideIcons.apple, color: AppColors.accent2),
        ],
      ),
    );
  }

  Widget _buildActionCard(BuildContext context, {required String title, required String subtitle, required IconData icon, required Color color}) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: AppRadii.radiusMd, side: BorderSide(color: color.withOpacity(0.2))),
      child: ListTile(
        leading: Container(padding: const EdgeInsets.all(AppSpacing.sm), decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: AppRadii.radiusSm), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(LucideIcons.chevronLeft, color: AppColors.accent5),
      ),
    );
  }
}
