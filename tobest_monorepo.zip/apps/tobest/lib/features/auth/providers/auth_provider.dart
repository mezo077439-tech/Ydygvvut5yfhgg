import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared/config/app_config.dart';
import '../../../core/providers.dart';
part 'auth_provider.g.dart';

enum AuthStatus { initial, authenticated, unauthenticated, loading, error }

class AuthState {
  final AuthStatus status;
  final String? errorMessage;
  final AppRole? role;
  const AuthState({this.status = AuthStatus.initial, this.errorMessage, this.role});
  AuthState copyWith({AuthStatus? status, String? errorMessage, AppRole? role}) {
    return AuthState(status: status ?? this.status, errorMessage: errorMessage, role: role ?? this.role);
  }
}

@Riverpod(keepAlive: true)
class AuthNotifier extends _$AuthNotifier {
  @override
  AuthState build() => const AuthState();

  Future<void> checkAuthStatus() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final token = await ref.read(localStorageProvider).getAuthToken();
      if (token != null) state = state.copyWith(status: AuthStatus.authenticated, role: AppRole.user);
      else state = state.copyWith(status: AuthStatus.unauthenticated);
    } catch (e) {
      state = state.copyWith(status: AuthStatus.unauthenticated);
    }
  }

  Future<void> login(String identifier, String password) async {
    state = state.copyWith(status: AuthStatus.loading, errorMessage: null);
    try {
      final response = await ref.read(gasApiProvider).callFunction('login', {
        'identifier': identifier, 'password': password, 'appContext': AppConfig.mainAppName,
      });

      AppRole userRole = _parseRole(response['role'] as String);
      if (!AppConfig.isMainAppRole(userRole)) throw Exception('غير مصرح لك بالدخول إلى هذا التطبيق.');
      
      await ref.read(localStorageProvider).saveAuthToken(response['token'] as String);
      state = state.copyWith(status: AuthStatus.authenticated, role: userRole);
    } catch (e) {
      state = state.copyWith(status: AuthStatus.error, errorMessage: e.toString().replaceAll('Exception: ', ''));
    }
  }

  Future<void> logout() async {
    await ref.read(localStorageProvider).clearAuthToken();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  AppRole _parseRole(String roleStr) {
    if (roleStr.toLowerCase() == 'coach') return AppRole.coach;
    return AppRole.user;
  }
}
