import 'package:flutter/material.dart';
import 'package:shared/design/tokens.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: isDark ? AppColors.backgroundDark : AppColors.backgroundLight,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDark ? AppColors.surfaceDark : AppColors.surfaceLight,
                boxShadow: [BoxShadow(color: AppColors.accent1.withOpacity(0.1), blurRadius: 20, spreadRadius: 5)],
              ),
              child: const Icon(Icons.fitness_center_rounded, size: 80, color: AppColors.accent1),
            ),
            const SizedBox(height: AppSpacing.xl),
            const Text('TO Best', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 2)),
            const SizedBox(height: AppSpacing.xxl),
            const CircularProgressIndicator(color: AppColors.accent1),
          ],
        ),
      ),
    );
  }
}
