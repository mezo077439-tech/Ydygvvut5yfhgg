import 'package:dio/dio.dart';
import '../config/secrets.dart';
import 'local_storage_service.dart';

class GasApiClient {
  final Dio _dio;
  final LocalStorageService _storage;

  GasApiClient(this._storage) : _dio = Dio() {
    _dio.options.baseUrl = AppSecrets.gasBaseUrl;
    _dio.options.connectTimeout = const Duration(seconds: 30);
    _dio.options.receiveTimeout = const Duration(seconds: 30);
    
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _storage.getAuthToken();
        final Map<String, dynamic> authData = {'secretKey': AppSecrets.gasSecretKey};
        if (token != null) authData['sessionId'] = token;

        if (options.data is Map<String, dynamic>) {
          options.data.addAll(authData);
        } else {
          options.data = authData;
        }
        options.headers['Content-Type'] = 'application/json';
        return handler.next(options);
      },
    ));
  }

  Future<Map<String, dynamic>> callFunction(String action, Map<String, dynamic> payload) async {
    try {
      final requestData = {'action': action, ...payload};
      final response = await _dio.post('', data: requestData, options: Options(followRedirects: true, validateStatus: (status) => status! < 500));

      if (response.statusCode == 200 || response.statusCode == 302) {
        final responseData = response.data;
        if (responseData['status'] == 'success') return responseData['data'] ?? {};
        else throw Exception(responseData['message'] ?? 'حدث خطأ غير معروف في الخادم');
      } else {
        throw Exception('فشل الاتصال بالخادم. الرمز: ${response.statusCode}');
      }
    } on DioException catch (e) {
      if (e.type == DioExceptionType.connectionTimeout || e.type == DioExceptionType.receiveTimeout) {
        throw Exception('انتهى وقت الاتصال، يرجى التحقق من جودة الإنترنت.');
      } else if (e.type == DioExceptionType.connectionError) {
        await _storage.saveOfflineRequest(action, payload);
        throw Exception('لا يوجد اتصال بالإنترنت. تم حفظ الطلب وسيتم المزامنة لاحقاً.');
      }
      throw Exception('خطأ في الشبكة: ${e.message}');
    }
  }
}
