import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'models/isar_models.dart';

class LocalStorageService {
  final FlutterSecureStorage _secureStorage;
  late final Isar _isar;

  LocalStorageService() : _secureStorage = const FlutterSecureStorage();

  Future<void> init() async {
    final dir = await getApplicationDocumentsDirectory();
    _isar = await Isar.open(
      [FoodItemEntitySchema, OfflineRequestEntitySchema],
      directory: dir.path,
    );
    await _seedFoodDatabaseIfEmpty();
  }

  Future<void> _seedFoodDatabaseIfEmpty() async {
    final count = await _isar.foodItemEntitys.count();
    if (count > 0) return;

    final initialFoods = [
      FoodItemEntity()..foodId = 'f_001'..nameAr = 'صدر دجاج مشوي'..nameEn = 'Grilled Chicken Breast'
        ..calories = 165..protein = 31..carbs = 0..fat = 3.6..defaultAmount = 100..unit = 'g',
      FoodItemEntity()..foodId = 'f_002'..nameAr = 'أرز أبيض مطبوخ'..nameEn = 'Cooked White Rice'
        ..calories = 130..protein = 2.7..carbs = 28..fat = 0.3..defaultAmount = 100..unit = 'g',
    ];

    await _isar.writeTxn(() async {
      await _isar.foodItemEntitys.putAll(initialFoods);
    });
  }

  Future<void> saveAuthToken(String token) async {
    await _secureStorage.write(key: 'auth_token', value: token);
  }

  Future<String?> getAuthToken() async {
    return await _secureStorage.read(key: 'auth_token');
  }

  Future<void> clearAuthToken() async {
    await _secureStorage.delete(key: 'auth_token');
  }

  Future<void> saveOfflineRequest(String endpoint, Map<String, dynamic> payload) async {
    final request = OfflineRequestEntity()
      ..endpoint = endpoint
      ..payloadJson = jsonEncode(payload)
      ..createdAt = DateTime.now();

    await _isar.writeTxn(() async {
      await _isar.offlineRequestEntitys.put(request);
    });
  }
}
