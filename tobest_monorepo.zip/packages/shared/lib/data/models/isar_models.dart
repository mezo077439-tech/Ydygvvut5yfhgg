import 'package:isar/isar.dart';
part 'isar_models.g.dart';

@collection
class FoodItemEntity {
  Id id = Isar.autoIncrement;
  @Index(unique: true, replace: true)
  late String foodId;
  late String nameAr;
  late String nameEn;
  late double calories;
  late double protein;
  late double carbs;
  late double fat;
  late double defaultAmount;
  late String unit;
}

@collection
class OfflineRequestEntity {
  Id id = Isar.autoIncrement;
  late String endpoint;
  late String payloadJson;
  late DateTime createdAt;
}
