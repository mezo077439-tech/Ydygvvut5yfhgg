import 'package:google_generative_ai/google_generative_ai.dart';
import '../config/secrets.dart';

class GeminiService {
  late final GenerativeModel _model;

  GeminiService() {
    _model = GenerativeModel(
      model: 'gemini-1.5-flash',
      apiKey: AppSecrets.geminiApiKey,
      generationConfig: GenerationConfig(temperature: 0.7, topK: 40, topP: 0.95, maxOutputTokens: 1024),
    );
  }

  Future<String> analyzeMealText(String userInput, String customPrompt) async {
    try {
      final prompt = '''
      $customPrompt
      
      النص المدخل من المستخدم:
      "$userInput"
      
      قم بالرد فقط ببيانات بصيغة JSON خالية من أي نصوص إضافية.
      ''';
      final response = await _model.generateContent([Content.text(prompt)]);
      if (response.text == null || response.text!.isEmpty) throw Exception('No valid response');
      String cleanedText = response.text!.trim().replaceFirst('```json', '').replaceFirst('```', '').trim();
      return cleanedText;
    } catch (e) {
      throw Exception('حدث خطأ أثناء التواصل مع الذكاء الاصطناعي: $e');
    }
  }
}
