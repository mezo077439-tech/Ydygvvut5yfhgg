import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'video_service.dart';

class VideoServiceDrive implements VideoService {
  final Dio _dio;
  static const int _maxCacheSizeBytes = 500 * 1024 * 1024; // 500 MB

  VideoServiceDrive() : _dio = Dio();

  String _generateFileName(String videoId) {
    return '${md5.convert(utf8.encode(videoId)).toString()}.mp4';
  }

  @override
  Future<List<VideoMetadata>> getVideosForExercise(String exerciseId) async => [];

  @override
  Future<String> getStreamUrl(String videoId) async {
    if (await isVideoCached(videoId)) {
      final tempDir = await getTemporaryDirectory();
      return 'file://${tempDir.path}/${_generateFileName(videoId)}';
    }
    return 'https://drive.google.com/uc?export=download&id=$videoId';
  }

  @override
  Future<bool> isVideoCached(String videoId) async {
    final tempDir = await getTemporaryDirectory();
    return await File('${tempDir.path}/${_generateFileName(videoId)}').exists();
  }

  @override
  Future<void> prefetchVideo(String videoId) async {
    if (await isVideoCached(videoId)) return;
    await clearVideoCache();
    final tempDir = await getTemporaryDirectory();
    final filePath = '${tempDir.path}/${_generateFileName(videoId)}';
    try {
      await _dio.download('https://drive.google.com/uc?export=download&id=$videoId', filePath);
    } catch (e) {
      if (await File(filePath).exists()) await File(filePath).delete();
      throw Exception('فشل تحميل الفيديو: $e');
    }
  }

  @override
  Future<void> clearVideoCache() async {
    final dir = Directory((await getTemporaryDirectory()).path);
    if (!await dir.exists()) return;
    final videoFiles = (await dir.list().toList()).whereType<File>().where((f) => f.path.endsWith('.mp4')).toList();
    int totalSize = 0;
    for (var file in videoFiles) totalSize += await file.length();

    if (totalSize > _maxCacheSizeBytes) {
      videoFiles.sort((a, b) => a.lastModifiedSync().compareTo(b.lastModifiedSync()));
      for (var file in videoFiles) {
        if (totalSize <= _maxCacheSizeBytes) break;
        final fileSize = await file.length();
        await file.delete();
        totalSize -= fileSize;
      }
    }
  }
}
