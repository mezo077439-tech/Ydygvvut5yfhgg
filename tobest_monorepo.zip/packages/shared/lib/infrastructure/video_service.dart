class VideoMetadata {
  final String videoId, name, driveUrl, exerciseId;
  final int durationSeconds;
  const VideoMetadata({required this.videoId, required this.name, required this.driveUrl, required this.durationSeconds, required this.exerciseId});
}

abstract class VideoService {
  Future<List<VideoMetadata>> getVideosForExercise(String exerciseId);
  Future<String> getStreamUrl(String videoId);
  Future<void> prefetchVideo(String videoId);
  Future<bool> isVideoCached(String videoId);
  Future<void> clearVideoCache();
}
