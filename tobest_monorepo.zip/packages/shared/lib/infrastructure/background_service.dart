import 'package:workmanager/workmanager.dart';

class BackgroundService {
  static const String _syncTask = "syncOfflineRequestsTask";

  static void initialize() {
    Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
  }

  static void registerPeriodicSync() {
    Workmanager().registerPeriodicTask(
      "1", _syncTask,
      frequency: const Duration(minutes: 30),
      constraints: Constraints(networkType: NetworkType.connected, requiresBatteryNotLow: true),
    );
  }
}

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == "syncOfflineRequestsTask") {
      try {
        return Future.value(true);
      } catch (e) {
        return Future.value(false);
      }
    }
    return Future.value(true);
  });
}
