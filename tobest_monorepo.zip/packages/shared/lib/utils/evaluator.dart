import 'package:flutter/material.dart';
import 'dart:math' as math;

class EvalResult {
  final String code;
  final String arabic;
  final String english;
  final IconData icon;
  const EvalResult(this.code, this.arabic, this.english, this.icon);
}

class SetRecord {
  final double weight;
  final int reps;
  const SetRecord({required this.weight, required this.reps});
}

class FoodItem {
  final String id;
  final String nameAr;
  final String nameEn;
  final double calories;
  final double protein;
  final double carbs;
  final double fat;
  final double amount;
  final String unit;

  const FoodItem({
    required this.id, required this.nameAr, required this.nameEn,
    required this.calories, required this.protein, required this.carbs,
    required this.fat, required this.amount, required this.unit,
  });

  FoodItem copyWithScaledAmount(double newAmount) {
    final double ratio = newAmount / amount;
    return FoodItem(
      id: id, nameAr: nameAr, nameEn: nameEn,
      calories: calories * ratio, protein: protein * ratio,
      carbs: carbs * ratio, fat: fat * ratio,
      amount: newAmount, unit: unit,
    );
  }
}

class MacroResult {
  final double calories, protein, carbs, fat;
  const MacroResult({required this.calories, required this.protein, required this.carbs, required this.fat});
}

class MealParseResult {
  final List<FoodItem> items;
  final double totalCalories;
  const MealParseResult(this.items, this.totalCalories);
}

class Evaluator {
  static const Map<String, EvalResult> states = {
    's1': EvalResult('s1', 'ممتاز جدا جدا', 'Outstanding', Icons.emoji_events),
    's2': EvalResult('s2', 'ممتاز جدا', 'Excellent', Icons.star),
    's3': EvalResult('s3', 'ممتاز', 'Great', Icons.thumb_up),
    'rv': EvalResult('rv', 'استعادة المستوى', 'Level Restored', Icons.update),
    'gd': EvalResult('gd', 'جيد', 'Good', Icons.check_circle),
    'st': EvalResult('st', 'ثبات', 'Stagnation', Icons.remove_circle_outline),
    'ws': EvalResult('ws', 'تحذير ثبات', 'Warning Plateau', Icons.warning_amber_rounded),
    'dn': EvalResult('dn', 'انخفاض', 'Decline', Icons.arrow_circle_down),
    'beg': EvalResult('beg', 'بداية', 'Beginning', Icons.play_circle_outline),
  };

  static double epley(double weight, int reps) {
    if (reps == 0 || weight == 0) return 0.0;
    if (reps == 1) return weight;
    return weight * (1.0 + (reps / 30.0));
  }

  static SetRecord? bestSet(List<SetRecord> sets) {
    if (sets.isEmpty) return null;
    return sets.reduce((curr, next) {
      final currScore = epley(curr.weight, curr.reps);
      final nextScore = epley(next.weight, next.reps);
      return currScore >= nextScore ? curr : next;
    });
  }

  static bool isStagnant3Weeks(List<double> historyEpleys) {
    const int stagnationWeeks = 3;
    if (historyEpleys.length < stagnationWeeks) return false;
    final recent = historyEpleys.sublist(historyEpleys.length - stagnationWeeks);
    final first = recent.first;
    return recent.every((val) => (val - first).abs() < 1.0);
  }

  static bool isRecovery(List<double> historyEpleys, double currWeight, int currReps) {
    if (historyEpleys.isEmpty) return false;
    final currScore = epley(currWeight, currReps);
    final maxHistory = historyEpleys.reduce(math.max);
    return currScore >= maxHistory && historyEpleys.last < maxHistory;
  }

  static bool checkPR(List<double> historyEpleys, double currWeight, int currReps) {
    if (historyEpleys.isEmpty) return true;
    final currScore = epley(currWeight, currReps);
    final maxHistory = historyEpleys.reduce(math.max);
    return currScore > maxHistory;
  }

  static EvalResult evaluate(double prevEpley, double currEpley, List<double> historyEpleys) {
    if (prevEpley == 0.0) return states['beg']!;
    final ratio = currEpley / prevEpley;
    if (isRecovery(historyEpleys, currEpley, 10)) return states['rv']!;
    if (ratio > 1.15) return states['s1']!;
    if (ratio > 1.08) return states['s2']!;
    if (ratio > 1.03) return states['s3']!;
    if (ratio > 0.98) {
      if (isStagnant3Weeks([...historyEpleys, currEpley])) return states['ws']!;
      return states['st']!;
    }
    if (ratio >= 0.90) return states['gd']!;
    return states['dn']!;
  }

  static String? repSuggestion(int reps) {
    if (reps >= 12) return 'increase_weight';
    if (reps <= 4) return 'decrease_weight';
    return null;
  }

  static double calcBMR(double weight, double height, int age, String gender) {
    double bmr = (10 * weight) + (6.25 * height) - (5 * age);
    return gender.toLowerCase() == 'male' ? bmr + 5 : bmr - 161;
  }

  static double calcTDEE(double bmr, double activityMultiplier) {
    return bmr * activityMultiplier;
  }

  static MacroResult calcMacros(double calories, String goal) {
    double proteinRatio = 0.30, carbsRatio = 0.45, fatRatio = 0.25;
    if (goal == 'cut') { proteinRatio = 0.40; carbsRatio = 0.35; }
    else if (goal == 'bulk') { proteinRatio = 0.25; carbsRatio = 0.50; }
    return MacroResult(
      calories: calories,
      protein: (calories * proteinRatio) / 4.0,
      carbs: (calories * carbsRatio) / 4.0,
      fat: (calories * fatRatio) / 9.0,
    );
  }

  static FoodItem adjustByAmount(FoodItem food, double newAmount) {
    return food.copyWithScaledAmount(newAmount);
  }

  static FoodItem adjustByCalories(FoodItem food, double targetCal) {
    if (food.calories == 0) return food;
    return food.copyWithScaledAmount(food.amount * (targetCal / food.calories));
  }

  static int _levenshtein(String s, String t) {
    if (s.isEmpty) return t.length;
    if (t.isEmpty) return s.length;
    List<int> v0 = List<int>.generate(t.length + 1, (i) => i);
    List<int> v1 = List<int>.filled(t.length + 1, 0);
    for (int i = 0; i < s.length; i++) {
      v1[0] = i + 1;
      for (int j = 0; j < t.length; j++) {
        int cost = (s[i] == t[j]) ? 0 : 1;
        v1[j + 1] = math.min(v1[j] + 1, math.min(v0[j + 1] + 1, v0[j] + cost));
      }
      for (int j = 0; j < v0.length; j++) v0[j] = v1[j];
    }
    return v1[t.length];
  }

  static MealParseResult parseMealText(String text, List<FoodItem> foodDB) {
    String normalized = text.replaceAll(RegExp(r'[ًٌٍَُِّْ]'), '').replaceAll(RegExp(r'[أإآ]'), 'ا').replaceAll('ة', 'ه').replaceAll('ى', 'ي');
    List<FoodItem> parsedItems = [];
    double totalCalories = 0.0;
    List<String> segments = normalized.split(RegExp(r'[،,و\n]+'));

    for (var segment in segments) {
      segment = segment.trim();
      if (segment.isEmpty) continue;
      final match = RegExp(r'^([\d\.]+)\s*(.*)').firstMatch(segment);
      double amount = 1.0;
      String itemName = segment;
      if (match != null) {
        amount = double.tryParse(match.group(1) ?? '1.0') ?? 1.0;
        itemName = match.group(2)!.trim();
      }

      FoodItem? bestMatch;
      int bestDist = 999;
      for (var food in foodDB) {
        int dist = _levenshtein(itemName, food.nameAr);
        if (dist < bestDist && dist < 4) { bestDist = dist; bestMatch = food; }
      }

      if (bestMatch != null) {
        final adjustedFood = adjustByAmount(bestMatch, amount);
        parsedItems.add(adjustedFood);
        totalCalories += adjustedFood.calories;
      }
    }
    return MealParseResult(parsedItems, totalCalories);
  }
}
