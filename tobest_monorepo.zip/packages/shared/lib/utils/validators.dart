class Validators {
  static String? validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) return 'البريد الإلكتروني مطلوب';
    final RegExp emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value)) return 'صيغة البريد الإلكتروني غير صحيحة';
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) return 'كلمة المرور مطلوبة';
    if (value.length < 8) return 'يجب أن تتكون كلمة المرور من 8 أحرف على الأقل';
    return null;
  }

  static String? validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) return 'رقم الهاتف مطلوب';
    final RegExp phoneRegex = RegExp(r'^\+?[0-9]{10,14}$');
    if (!phoneRegex.hasMatch(value)) return 'رقم الهاتف غير صحيح';
    return null;
  }

  static String? validateNumeric(String? value, {String fieldName = 'هذا الحقل'}) {
    if (value == null || value.trim().isEmpty) return '$fieldName مطلوب';
    if (double.tryParse(value) == null) return 'يجب إدخال أرقام فقط';
    return null;
  }
}
