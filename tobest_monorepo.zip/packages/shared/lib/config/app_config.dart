enum AppRole {
  user,
  coach,
  manager,
  support,
  subscriptions,
}

class AppConfig {
  static const String mainAppName = 'TO Best';
  static const String managementAppName = 'TO Best Management';
  static const int otpValidityMinutes = 10;
  static const int otpResendCooldownSeconds = 60;

  static bool isMainAppRole(AppRole role) {
    return role == AppRole.user || role == AppRole.coach;
  }

  static bool isManagementAppRole(AppRole role) {
    return role == AppRole.manager || 
           role == AppRole.support || 
           role == AppRole.subscriptions;
  }
}
