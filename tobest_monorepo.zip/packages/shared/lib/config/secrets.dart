class AppSecrets {
  static const String gasBaseUrl = 'REPLACE_WITH_GAS_URL';
  static const String gasSecretKey = 'REPLACE_WITH_SECRET_KEY';
  static const String geminiApiKey = 'REPLACE_WITH_GEMINI_KEY';
}
