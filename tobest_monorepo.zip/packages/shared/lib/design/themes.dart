import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'tokens.dart';

class AppThemes {
  static TextTheme _buildTextTheme(String languageCode, Color textColor) {
    if (languageCode == 'ar') {
      return GoogleFonts.cairoTextTheme().apply(
        bodyColor: textColor,
        displayColor: textColor,
      );
    } else {
      return GoogleFonts.interTextTheme().apply(
        bodyColor: textColor,
        displayColor: textColor,
      );
    }
  }

  static ThemeData getLightTheme(String languageCode) {
    return ThemeData(
      brightness: Brightness.light,
      primaryColor: AppColors.accent1,
      scaffoldBackgroundColor: AppColors.backgroundLight,
      cardColor: AppColors.surfaceLight,
      textTheme: _buildTextTheme(languageCode, AppColors.textPrimaryLight),
      colorScheme: const ColorScheme.light(
        primary: AppColors.accent1,
        secondary: AppColors.accent2,
        surface: AppColors.surfaceLight,
      ),
      useMaterial3: true,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.surfaceLight,
        foregroundColor: AppColors.textPrimaryLight,
        elevation: 0,
        centerTitle: true,
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: AppRadii.radiusMd,
      ),
    );
  }

  static ThemeData getDarkTheme(String languageCode) {
    return ThemeData(
      brightness: Brightness.dark,
      primaryColor: AppColors.accent1,
      scaffoldBackgroundColor: AppColors.backgroundDark,
      cardColor: AppColors.surfaceDark,
      textTheme: _buildTextTheme(languageCode, AppColors.textPrimaryDark),
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent1,
        secondary: AppColors.accent2,
        surface: AppColors.surfaceDark,
      ),
      useMaterial3: true,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.surfaceDark,
        foregroundColor: AppColors.textPrimaryDark,
        elevation: 0,
        centerTitle: true,
      ),
    );
  }

  static ThemeData getBlueTheme(String languageCode) {
    return getDarkTheme(languageCode).copyWith(
      primaryColor: AppColors.accent1,
      scaffoldBackgroundColor: const Color(0xFF0B1120),
      colorScheme: const ColorScheme.dark(
        primary: AppColors.accent1,
        secondary: Color(0xFF38BDF8),
        surface: Color(0xFF1E293B),
      ),
    );
  }

  static ThemeData getPinkTheme(String languageCode) {
    return getLightTheme(languageCode).copyWith(
      primaryColor: AppColors.accent4,
      scaffoldBackgroundColor: const Color(0xFFFFF1F2),
      colorScheme: const ColorScheme.light(
        primary: AppColors.accent4,
        secondary: Color(0xFFFB7185),
        surface: Colors.white,
      ),
    );
  }
}
